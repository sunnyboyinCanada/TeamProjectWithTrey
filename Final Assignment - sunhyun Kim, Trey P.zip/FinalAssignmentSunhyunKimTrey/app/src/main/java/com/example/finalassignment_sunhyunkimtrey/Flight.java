package com.example.finalassignment_sunhyunkimtrey;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import static com.example.finalassignment_sunhyunkimtrey.GameView.screenRationX;
import static com.example.finalassignment_sunhyunkimtrey.GameView.screenRationY;


public class Flight {

    boolean isGoingup = false;
    int x, y,width, height, wingCounter = 0;
    Bitmap flight1,flight2;

    Flight (int screenY, Resources res){

        flight1 = BitmapFactory.decodeResource(res,R.drawable.PlaneForPlayer);
        flight2 = BitmapFactory.decodeResource(res,R.drawable.PlaneForPlayer);

        width = flight1.getWidth();
        height = flight1.getHeight();

        width /= 4;
        height /= 4;

        width *= (int) screenRationX;
        height *= (int) screenRationY;

        flight1 = Bitmap.createScaledBitmap(flight1, width,height,false);
        flight2 = Bitmap.createScaledBitmap(flight2,width,height,false);

        y=screenY/2;
        x = (int)(64 * screenRationY);
    }

    Bitmap getFlight(){
        if (wingCounter == 0){
            wingCounter++;
            return  flight1;
        }

        wingCounter--;

        return flight2;
    }
}
